# Titulo: Transformación de datos

# Propósito: Este script introduce como ordenar y reordenar datos  

# Autor: Pastor E. Pérez Estigarribia
# e-mail: peperez.estigarribia@pol.una.py

Sys.time()

# Fecha de implementación del script: "2022-09-30 19:58:49 -04" 
# Fecha de ultima modificación: ""2022-09-30 19:58:49 -04"


# Preámbulo 

# Instalar paquetes 

if (!require('pacman'))
  install.packages("pacman")
library(pacman)

pacman::p_load(tidyverse,
               rio)

getwd()

# En el menu help ir a -> cheat sheets luego a -> Browse cheat sheets...


#  0. Pivotear tablas anchas a largas y largas a anchas 

browseURL("https://tidyr.tidyverse.org/articles/pivot.html")

# 1. Tablas largas ####

# pivot_longer() hace que los conjuntos de datos sean más largos 
# aumentando el número de filas y disminuyendo el número de columnas.


relig_income # ingreso anual según la religión 

View(relig_income)


relig_income %>%
  pivot_longer(!religion, names_to = "income", values_to = "count") %>% 
  View()

# Datos numéricos en nombres de columna

# El conjunto de datos billboard registra la clasificación de las
# canciones en la cartelera en el año 2000. Tiene una forma similar 
# a los relig_incomedatos, pero los datos codificados en los nombres 
# de las columnas son en realidad un número, no una cadena.

billboard

# Aquí queremos que los nombres se conviertan en una variable llamada week, 
# y los valores se conviertan en una variable llamada rank.

billboard %>% 
  pivot_longer(
    cols = starts_with("wk"), 
    names_to = "week", 
    values_to = "rank",
    values_drop_na = TRUE
  )

# Sería bueno determinar fácilmente cuánto tiempo permaneció cada canción en
# las listas, pero para hacerlo, necesitaremos convertir la weekvariable
# en un número entero.

billboard %>% 
  pivot_longer(
    cols = starts_with("wk"), 
    names_to = "week", 
    names_prefix = "wk",
    names_transform = list(week = as.integer),
    values_to = "rank",
    values_drop_na = TRUE,
  )

# Alternativamente, puede hacer esto con un solo argumento usando 
# readr::parse_number()which elimina automáticamente los componentes no numéricos:

billboard %>% 
  pivot_longer(
    cols = starts_with("wk"), 
    names_to = "week", 
    names_transform = list(week = readr::parse_number),
    values_to = "rank",
    values_drop_na = TRUE,
  )

# 2. tablas anchas ####

# El conjunto de datos fish_encounters, aportado por Myfanwy Johnston ,
# describe cuándo las estaciones de monitoreo automático detectan 
# peces que nadan río abajo:

fish_encounters

fish_encounters %>% 
  pivot_wider(names_from = station, values_from = seen)

# Este conjunto de datos solo registra cuándo la estación detectó 
# un pez; no registra cuándo no se detectó (esto es común con este 
# tipo de datos). Eso significa que los datos de salida están 
# llenos de NAs. Sin embargo, en este caso sabemos que la ausencia
# de un registro significa que el pez no era seen, por lo que 
# podemos solicitar pivot_wider()que complete estos valores 
# faltantes con ceros:

fish_encounters %>% pivot_wider(
  names_from = station, 
  values_from = seen,
  values_fill = 0
)

# 3. Agregación ####

# También puede utilizar pivot_wider()para realizar una agregación simple. 
# Por ejemplo, tome el warpbreaksconjunto de datos integrado en la base R 
# (convertido a un tibble para un mejor método de impresión):

warpbreaks

warpbreaks <- warpbreaks %>% 
  as_tibble() %>% select(wool, tension, breaks)
warpbreaks

# Este es un experimento diseñado con nueve repeticiones para cada combinación
# de wool( Ay B) y tension( L, M, H):

warpbreaks %>% count(wool, tension)

str(warpbreaks)

View(warpbreaks)

# Ahora podemos obtener estadísticas resumidas, por ejemplo,  mean para 
# cada combinación de lana y tensión:

warpbreaks %>% 
  pivot_wider(
    names_from = wool, 
    values_from = breaks,
    values_fn = list(breaks = mean)
  )


# 4. Generar nombre de columna a partir de múltiples variables ####


# Imagine, como en https://stackoverflow.com/questions/24929954 , 
# que tenemos información que contiene la combinación de producto, 
# país y año. En forma ordenada podría verse así:

?expand_grid

production <- expand_grid(
  product = c("A", "B"), 
  country = c("AI", "EI"), 
  year = 2000:2014
) %>%
  filter((product == "A" & country == "AI") | product == "B") %>% 
  mutate(production = rnorm(nrow(.)))
production 

class(production)


nrow(production)

# Queremos ampliar los datos para tener una columna para cada combinación 
# de producty country. La clave es especificar múltiples variables 
# para names_from:

production %>% pivot_wider(
  names_from = c(product, country), 
  values_from = production
)

# 5. censo ordenado #### 

# El conjunto de datos us_rent_income contiene información sobre 
# el ingreso medio y el alquiler de cada estado de los EE. UU. para 2017 
#(de la Encuesta sobre la comunidad estadounidense, recuperada con
# el paquete tidycensus).

browseURL("https://walker-data.com/tidycensus/")

us_rent_income

# Aquí ambos estimate y moe son columnas de valores, por lo que 
# podemos proporcionarlos a values_from:

us_rent_income %>% 
  pivot_wider(names_from = variable, values_from = c(estimate, moe))

# 6. Expandir tablas ####

# Cree nuevas combinaciones de variables o identifique valores perdidos 
# implícitos (combinaciones de variables que no están 
# presentes en los datos

# Agregue las posibles combinaciones faltantes de los valores de 
# las variables enumeradas en

mtcars

complete(mtcars, cyl, gear,
         carb)

# 7. Separar datos de celdas 

table5

# unir dos variables en una 

unite(table5, century, year, col = "year", sep = "")

# Separar una variable en dos 

table3 

separate(table3, rate, sep = "/",
         into = c("cases", "pop")) %>% 
  mutate(tasa = 100000*as.numeric(cases)/as.numeric(pop))

# Separar en filas 

table3

separate_rows(table3, rate, sep = "/")
